/**
 * @默认配置
 * url---------------请求的url-------------string
 * version-----------版本号----------------string
 * headers---------- 请求头----------------object
 * author_key--------用户Accesskey---------string
 * user_id-----------用户ID----------------string
 */
let config = {
  url: 'https://openapi.heclouds.com',
  version: '1'
}

module.exports = {
  config
}
